package com.mycompany.clinicaprogii;

import java.util.Scanner;

public class ClinicaProgII {
    public static void main(String[] args) {
        Clinica clinica = new Clinica();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n--- Clínica de Exames ---");
            System.out.println("1 - Cadastrar Paciente");
            System.out.println("2 - Cadastrar Exame");
            System.out.println("3 - Agendar Exame");
            System.out.println("4 - Listar Agendamentos");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1:
                    System.out.print("Nome do paciente: ");
                    String nomePaciente = scanner.nextLine();
                    System.out.print("CPF do paciente: ");
                    String cpf = scanner.nextLine();
                    clinica.adicionarPaciente(new Paciente(nomePaciente, cpf));
                    System.out.println("Paciente cadastrado!");
                    break;

                case 2:
                    System.out.print("Nome do exame: ");
                    String nomeExame = scanner.nextLine();
                    System.out.print("Preço do exame: ");
                    double preco = scanner.nextDouble();
                    scanner.nextLine();
                    clinica.adicionarExame(new Exame(nomeExame, preco));
                    System.out.println("Exame cadastrado!");
                    break;

                case 3:
                    System.out.print("CPF do paciente: ");
                    String cpfBusca = scanner.nextLine();
                    Paciente paciente = clinica.buscarPacientePorCPF(cpfBusca);
                    if (paciente == null) {
                        System.out.println("Paciente não encontrado.");
                        break;
                    }

                    System.out.print("Nome do exame: ");
                    String nomeExameBusca = scanner.nextLine();
                    Exame exame = clinica.buscarExamePorNome(nomeExameBusca);
                    if (exame == null) {
                        System.out.println("Exame não encontrado.");
                        break;
                    }

                    System.out.print("Data do agendamento (dd/mm/aaaa): ");
                    String data = scanner.nextLine();

                    clinica.adicionarAgendamento(new Agendamento(paciente, exame, data));
                    System.out.println("Agendamento realizado!");
                    break;

                case 4:
                    System.out.println("\n--- Lista de Agendamentos ---");
                    for (Agendamento a : clinica.listarAgendamentos()) {
                        System.out.println(a);
                    }
                    break;

                case 0:
                    System.out.println("Encerrando...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        scanner.close();
    }
}

