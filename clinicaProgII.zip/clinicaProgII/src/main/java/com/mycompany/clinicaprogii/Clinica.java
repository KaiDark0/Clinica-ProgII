package com.mycompany.clinicaprogii;

import java.util.ArrayList;
import java.util.List;

public class Clinica {
    private List<Paciente> pacientes = new ArrayList<>();
    private List<Exame> exames = new ArrayList<>();
    private List<Agendamento> agendamentos = new ArrayList<>();

    public void adicionarPaciente(Paciente paciente) {
        pacientes.add(paciente);
    }

    public void adicionarExame(Exame exame) {
        exames.add(exame);
    }

    public void adicionarAgendamento(Agendamento agendamento) {
        agendamentos.add(agendamento);
    }

    public List<Paciente> listarPacientes() {
        return pacientes;
    }

    public List<Exame> listarExames() {
        return exames;
    }

    public List<Agendamento> listarAgendamentos() {
        return agendamentos;
    }

    public Paciente buscarPacientePorCPF(String cpf) {
        for (Paciente p : pacientes) {
            if (p.getCpf().equals(cpf)) {
                return p;
            }
        }
        return null;
    }

    public Exame buscarExamePorNome(String nome) {
        for (Exame e : exames) {
            if (e.getNome().equalsIgnoreCase(nome)) {
                return e;
            }
        }
        return null;
    }
}
