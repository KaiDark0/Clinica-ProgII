package com.mycompany.clinicaprogii;

public class Agendamento {
    private Paciente paciente;
    private Exame exame;
    private String data;

    public Agendamento(Paciente paciente, Exame exame, String data) {
        this.paciente = paciente;
        this.exame = exame;
        this.data = data;
    }

    @Override
    public String toString() {
        return "Agendamento: " + paciente.getNome() + 
               " | Exame: " + exame.getNome() + 
               " | Data: " + data;
    }
}
